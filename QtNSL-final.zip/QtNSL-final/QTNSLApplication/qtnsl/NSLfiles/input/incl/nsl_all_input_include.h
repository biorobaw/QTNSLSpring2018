/* SCCS  @(#)nsl_all_input_include.h	1.3---97/03/05--19:45:19 */

/****************************************************************/
/*                                                           	*/
/*                     nsl_all_input_include.h                  */
/*                                                            	*/
/****************************************************************/

# include "nsl_input_include.h" 
# include "nsl_cmd_input_include.h" 

/* # include "nsl_other_include.h" */



