/* SCCS  @(#)nsl_all_kernel_include.h	1.2---95/10/03--13:59:07 */
/****************************************************************/
/*                                                           	*/
/*                  nsl_all_kernel_include.h                    */
/*                                                            	*/
/****************************************************************/

#include "nsl2.h"
//# include "nsl_other_include.h"
//# include "nsl_library_include.h"
//# include "nsl_kernel_include.h" 
//# include "nsl_command_include.h" 
