/* SCCS  @(#)nsl_matrix_expdecay_library.h	1.1---95/08/13--23:38:58 */
//
// nsl_matrix_expdecay_library.h
//

extern nsl_num_2 NSLexpdecay(const nsl_num_2&,const nsl_num_0&);
