/* SCCS  @(#)nsl_vector_gauss_library.h	1.2---95/08/14--16:08:57 */
/****************************************************************/
/*                                                           	*/
/*                  nsl_vector_gauss_library.h                  */
/*                                                            	*/
/****************************************************************/

#ifndef _NSL_GAUSS_H
#define _NSL_GAUSS_H
extern nsl_num_1 NSLgauss(const nsl_num_0&,const int);
#endif
