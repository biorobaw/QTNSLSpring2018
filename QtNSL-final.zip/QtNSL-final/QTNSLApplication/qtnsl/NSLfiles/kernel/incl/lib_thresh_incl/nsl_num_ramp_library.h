/* SCCS  @(#)nsl_num_ramp_library.h	1.2---95/08/14--16:08:57 */
/****************************************************************/
/*                                                           	*/
/*                  nsl_num_ramp_library.h                      */
/*                                                            	*/
/****************************************************************/

extern num_type NSLramp(const num_type);
extern num_type NSLramp(const num_type,const num_type);
extern num_type NSLramp(const num_type,const num_type,
	const num_type,const num_type);
