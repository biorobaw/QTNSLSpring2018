/* SCCS  @(#)nsl_num_sat_library.h	1.2---95/08/14--16:08:57 */
/****************************************************************/
/*                                                           	*/
/*                  nsl_num_sat_library.h                       */
/*                                                            	*/
/****************************************************************/

extern num_type NSLsat(const num_type);
extern num_type NSLsat(const num_type,const num_type,const num_type);
extern num_type NSLsat(const num_type,const num_type,
	const num_type,const num_type,const num_type);
