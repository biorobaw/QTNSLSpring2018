/****************************************************************/
/*                                                           	*/
/*                  nsl_all_kernel_include.h                    */
/*                                                            	*/
/****************************************************************/

# include "nsl.h"

//# include "nsl_other_include.h"
//# include "nsl_library_include.h"
# include "nsl_kernel_include.h" 
//# include "nsl_command_include.h" 
