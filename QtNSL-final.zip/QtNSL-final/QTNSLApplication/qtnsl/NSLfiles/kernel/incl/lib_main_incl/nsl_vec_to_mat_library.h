/* SCCS  @(#)nsl_vec_to_mat_library.h	1.2---95/08/14--16:08:57 */
/****************************************************************/
/*                                                           	*/
/*                  nsl_vec_to_mat_library.h                    */
/*                                                            	*/
/****************************************************************/

extern nsl_num_2 NSLvec_to_mat(const nsl_num_2&,const nsl_num_1&);
extern nsl_num_2 NSLcol_vec_to_mat(const nsl_num_2&,const nsl_num_1&);
extern nsl_num_2 NSLrow_vec_to_mat(const nsl_num_2&,const nsl_num_1&);
extern nsl_num_2 NSLcol_vec_to_mat(const nsl_num_1&,const int);
extern nsl_num_2 NSLrow_vec_to_mat(const nsl_num_1&,const int);

