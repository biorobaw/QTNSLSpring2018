/* SCCS  @(#)nsl_mat_vec_prod_library.h	1.2---95/08/14--16:08:57 */
/****************************************************************/
/*                                                           	*/
/*                  nsl_mat_vec_prod_library.h                  */
/*                                                            	*/
/****************************************************************/

extern nsl_num_0 NSLprod(const nsl_num_1&,const nsl_num_1&);
extern nsl_num_1 NSLprod(const nsl_num_1&,const nsl_num_2&);
extern nsl_num_1 NSLprod(const nsl_num_2&,const nsl_num_1&);
extern nsl_num_2 NSLprod(const nsl_num_2&,const nsl_num_2&);

