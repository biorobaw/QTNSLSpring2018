/* SCCS  @(#)nsl_matrix_max_library.h	1.2---95/08/14--16:08:57 */
/****************************************************************/
/*                                                           	*/
/*                  nsl_matrix_max_library.h                    */
/*                                                            	*/
/****************************************************************/

extern nsl_num_2 NSLmax(const nsl_num_2&,const nsl_num_2&);
extern nsl_num_2 NSLmax(const nsl_num_2&,const nsl_num_0&);
extern nsl_num_2 NSLmax(const nsl_num_2&,const num_type);

