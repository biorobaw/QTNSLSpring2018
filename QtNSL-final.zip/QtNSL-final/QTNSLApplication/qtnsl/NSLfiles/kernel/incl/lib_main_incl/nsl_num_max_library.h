/* SCCS  @(#)nsl_num_max_library.h	1.2---95/08/14--16:08:57 */
/****************************************************************/
/*                                                           	*/
/*                  nsl_num_max_library.h                       */
/*                                                            	*/
/****************************************************************/

extern num_type NSLmax(const nsl_num_1&);
extern num_type NSLmax(const nsl_num_2&);
