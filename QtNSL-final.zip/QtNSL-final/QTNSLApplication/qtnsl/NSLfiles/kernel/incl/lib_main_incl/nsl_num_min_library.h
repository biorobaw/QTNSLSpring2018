/* SCCS  @(#)nsl_num_min_library.h	1.2---95/08/14--16:08:57 */
/****************************************************************/
/*                                                           	*/
/*                  nsl_num_min_library.h                       */
/*                                                            	*/
/****************************************************************/

extern num_type NSLmin(const nsl_num_1&);
extern num_type NSLmin(const nsl_num_2&);
