#ifndef _NSL_STREAM_H
#define _NSL_STREAM_H
#include "nsl_buffer_stream_library.h"
#include "nsl_interpreter_stream_library.h"
#include "nsl_nsl_file_stream_library.h"
#include "nsl_streambuf_stream_library.h"
#include "nsl_char_buf_stream_library.h"
#endif
