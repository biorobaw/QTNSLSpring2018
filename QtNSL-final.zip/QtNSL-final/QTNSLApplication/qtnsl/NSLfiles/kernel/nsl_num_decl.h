class nsl_num_0;
class nsl_num_1;
class nsl_num_2;

//typedef nsl_num_0 nsl_num_0;
//typedef nsl_num_1 nsl_num_1;
//typedef nsl_num_2 nsl_num_2;