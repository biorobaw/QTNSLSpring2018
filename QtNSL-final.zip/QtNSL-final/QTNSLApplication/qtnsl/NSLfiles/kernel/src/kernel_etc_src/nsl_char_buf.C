/* SCCS  @(#)nsl_char_buf.C	1.1---95/10/13--16:36:58 */
/**************************************************************/
/*                                                            */
/*                       nsl_char_buf.C 		      */
/*                                                            */
/**************************************************************/
#include "nsl_kernel.h"
#include "nsl_char_buf.h"

nsl_char_buf::nsl_char_buf() 
{
}
nsl_char_buf::~nsl_char_buf()
{
}
